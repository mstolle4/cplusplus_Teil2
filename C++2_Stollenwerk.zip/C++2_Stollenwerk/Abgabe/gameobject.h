#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include <QString>
#include <QWidget>
#include <QBrush>

class GameObject
{
public:
    GameObject(int pIndex);
    GameObject(int pIndex, int pX, int pY);
    ~GameObject();
    bool collides(QRect* player);
    void serializeIt(QString* pString);
    bool hasCollision;
    void drawObject(QPainter* painter, bool freeze);
    void moveObject();
    int getY(){return y;}
    int getX(){return x;}
    void setY(int pY){y = pY;};
    void setX(int pX){x = pX;};
private:
    int index;
    int x;
    int y;
    int size;
    int speed;
    QBrush customBrush;
};

#endif // GAMEOBJECT_H
