#include "gameobject.h"
#include <QBrush>
#include <QPen>
#include <QWidget>
#include <math.h>
#include <QPainter>
#include <QTime>


GameObject::GameObject(int PIndex)
{
    index = PIndex;
    x = 40 + (qrand() % 940);
    y = 45;
    speed = 1;
    size = 10;
    customBrush = QBrush(QColor(255,0,0));
}

GameObject::GameObject(int PIndex, int pX, int pY)
{
    index = PIndex;
    x = pX;
    y = pY;
    speed = 1;
    size = 10;
    customBrush = QBrush(QColor(255,0,0));
}

GameObject::~GameObject(){
}

void GameObject::drawObject(QPainter* painter, bool freeze){
    QPen myPen = QPen(Qt::black, 1, Qt::SolidLine, Qt::SquareCap, Qt::BevelJoin);
    painter->setPen(myPen);
    painter->setBrush(customBrush);
    painter->drawRect(x,y,size,size);
    if(!freeze){
        moveObject();
    }
}

void GameObject::moveObject(){
    y += speed;
}

bool GameObject::collides(QRect* player){
    if(player->contains(x+size,y+size)){
        return true;
    }
    else if(player->contains(x,y)){
        return true;
    }
    else if(player->contains(x,y+size)){
        return true;
    }
    else if(player->contains(x+size, y)){
        return true;
    }
    else
        return false;
}
