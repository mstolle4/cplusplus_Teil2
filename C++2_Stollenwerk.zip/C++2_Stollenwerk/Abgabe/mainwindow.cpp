#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "zeichenfeld.h"
#include <QFileDialog>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    pause = false;
    setFixedHeight(this->height());
    setFixedWidth(this->width());
    setFixedSize(this->size());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent* event){
    ui->zeichenfeld->UpdateSpeed(event);
}
void MainWindow::on_pushButton_clicked()
{
    if(!pause){
        ui->pushButton->setText("Pause");
        ui->zeichenfeld->changeAnimation();
        pause = !pause;
    }
    else{
        ui->pushButton->setText("Start");
        ui->zeichenfeld->changeAnimation();
        pause = !pause;
    }

}

void MainWindow::saveThis(){
    QFileDialog dialog(this);
    QString fileName;
    QFile file;
    pause = true;
    ui->pushButton->setText("Start");
    ui->zeichenfeld->pause();
    dialog.setFileMode(QFileDialog::AnyFile);
    fileName = dialog.getSaveFileName(this, tr("Speichern als"),".",tr("Savegame (*.savegame)"));

    if(!fileName.isEmpty()){
        file.setFileName(fileName);
        if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QMessageBox::warning(this, tr("Dateifehler"),
                                 tr("Folgende Datei kann nicht verwendet werden: ") + fileName,QMessageBox::Ok);
        }
        ui->zeichenfeld->save(&file);
        file.close();
        return;
    }
}

void MainWindow::loadThis(){
    QFileDialog dialog(this);
    QString fileName;
    QFile file;

    dialog.setFileMode(QFileDialog::AnyFile);
    fileName = dialog.getOpenFileName(this, tr("Datei öffnen..."),".",tr("Savegame (*.savegame)"));

    if(!fileName.isEmpty()){
        file.setFileName(fileName);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QMessageBox::warning(this, tr("Dateifehler"),
                                 tr("Folgende Datei kann nicht verwendet werden: ") + fileName,QMessageBox::Ok);
        }
        ui->zeichenfeld->load(&file);
        file.close();
        return;
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    saveThis();
}

void MainWindow::on_pushButton_3_clicked(){
    loadThis();
}
