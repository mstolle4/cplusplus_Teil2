#include "zeichenfeld.h"
#include <QPaintEvent>
#include <QPainter>
#include <QPen>
#include <QBrush>
#include <QKeyEvent>
#include "gameobject.h"
#include <QTextStream>
#include <QString>
#include <QDebug>

zeichenfeld::zeichenfeld(QWidget *parent) : QWidget(parent){
    setPalette(QPalette(QColor(255,255,255)));
    setAutoFillBackground(true);
    setMouseTracking(false);
    setUpdatesEnabled(true);
    sec = 0.0f;
    x = 475;
    y = 400;
    speed = 5;
    animated = false;
    points = 0;
    SPoints = QString::number(points);
    lives = 3;
    freeze = false;
    GameObjects.insert(0, GameObject(0));

    QPainter painter;
    QPen myPen = QPen(Qt::black, 3, Qt::SolidLine, Qt::SquareCap, Qt::BevelJoin);
    painter.begin(this);
    painter.setPen(myPen);
    //painter.setBrush(brush3);
    painter.drawText(20,10, "Punkte");
    painter.end();

    Updatetimer = new QTimer(this);
    Updatetimer->setSingleShot(false);
    connect(Updatetimer, SIGNAL(timeout()), this, SLOT(update()));
    connect(Updatetimer, SIGNAL(timeout()), this, SLOT(UpdatePoints()));
    connect(Updatetimer, SIGNAL(timeout()), this, SLOT(SpawnObject()));
}


void zeichenfeld::paintEvent(QPaintEvent* event){

    QPainter painter;
    QPen myPen = QPen(Qt::black, 3, Qt::SolidLine, Qt::SquareCap, Qt::BevelJoin);

    painter.begin(this);
    painter.setPen(myPen);
    SPoints = QString::number(points);
    painter.drawText(20,20, SPoints);
    painter.drawText(40,20, "Punkte");
    drawPlayer(&painter);
    drawLives(&painter);
    if(animated){
        if(GameObjects.count() > 0)
            if(!freeze){
                drawObjects(&painter, false);
            }else{
                drawObjects(&painter, true);
            }
    }
    else{
            drawObjects(&painter, true);
        }
        painter.end();
}

void zeichenfeld::drawPlayer(QPainter* painter){
    QPen myPen = QPen(Qt::black, 1, Qt::SolidLine, Qt::SquareCap, Qt::BevelJoin);
    painter->setPen(myPen);
    painter->drawRect(x, y, 25, 25);
    painter->drawLine(x,y+5,x+5,y);
    painter->drawLine(x,y+10,x+10,y);
    painter->drawLine(x,y+15,x+15,y);
    painter->drawLine(x,y+20,x+20,y);
    painter->drawLine(x,y+25,x+25,y);
    painter->drawLine(x+5,y+25,x+25,y+5);
    painter->drawLine(x+10,y+25,x+25,y+10);
    painter->drawLine(x+15,y+25,x+25,y+15);
    painter->drawLine(x+20,y+25,x+25,y+20);
}

void zeichenfeld::drawObjects(QPainter* painter, bool move){
    int i = 0;
    while(i < GameObjects.count()){
        GameObjects[i].drawObject(painter, move);
        if(GameObjects[i].collides(new QRect(x,y,25,25))){
            GameObjects[i].~GameObject();
            GameObjects[i] = GameObject(i);
            lives -= 1;
        }
        if(GameObjects[i].getY() >= 430){
            GameObjects[i].~GameObject();
            GameObjects[i] = GameObject(i);
        }
        i++;
    }
}

void zeichenfeld::UpdatePoints(){
    if(sec >= 50 && !freeze){
        points++;
        sec = 0.0f;
    }
    else if(!freeze){
        sec += 1.0f;
    }
}

void zeichenfeld::UpdateSpeed(QKeyEvent* event){
    if(animated ){
        if(!freeze){
            if(event->key() == Qt::Key_Right){
                speed = 5;
                if(x + speed <= 930)
                    x += speed;
            }
            else if(event->key() == Qt::Key_Left){
                speed = 5;
                if( x - speed >= 20)
                    x -= speed;
            }
        }
    }
}

void zeichenfeld::SpawnObject(){
    if(GameObjects.count() < 50 && ((qrand() % 100) < 12) && animated){
        GameObjects.append(GameObject(GameObjects.count()));
        GameObjects[GameObjects.count()-1].hasCollision = true;
    }

}

void zeichenfeld::drawLives(QPainter* painter){
    switch (lives) {
    case (3):
        painter->setBrush(QBrush(QColor(255,80,80)));
        painter->drawEllipse(QRectF(700,20,20,20));
        painter->drawEllipse(QRectF(730,20,20,20));
        painter->drawEllipse(QRectF(760,20,20,20));
        break;
    case (2):
        painter->setBrush(QBrush(QColor(255,255,255)));
        painter->drawEllipse(QRectF(700,20,20,20));
        painter->setBrush(QBrush(QColor(255,80,80)));
        painter->drawEllipse(QRectF(730,20,20,20));
        painter->drawEllipse(QRectF(760,20,20,20));
        break;
    case (1):
        painter->setBrush(QBrush(QColor(255,255,255)));
        painter->drawEllipse(QRectF(700,20,20,20));
        painter->drawEllipse(QRectF(730,20,20,20));
        painter->setBrush(QBrush(QColor(255,80,80)));
        painter->drawEllipse(QRectF(760,20,20,20));
        break;
    default:
        lives = 0;
        freeze = true;
        animated = false;
    }
}

void zeichenfeld::save(QFile* saveFile){
    QTextStream out(saveFile);
    if(animated)
        out << 1 << " ";
    else
        out << 0 << " ";
    if(freeze)
        out << 1 << " ";
    else
        out << 0 << " ";
    out << lives << " " << points << " " << sec << " " << x << endl;
    int i = 0;
    while(i < GameObjects.count()){
        out << GameObjects[i].getX() << " " << GameObjects[i].getY() << endl;
        i++;
    }
    update();
}

void zeichenfeld::load(QFile* loadFile){
    QTextStream in(loadFile);
    int temp, temp1;
    if(in.status() == QTextStream::Ok){
        qDebug() << "Hier startet der Ladevorgang";
        in >> temp;
        qDebug() << temp << endl;
        if(temp == 1){
            this->animated = true;
        }
        else{
            this->animated = false;
        }
        in >> temp;
        qDebug() << temp << endl;
        if(temp == 1){
            this->freeze = true;
        }
        else{
            this->freeze = false;
        }
        in >> lives;
        qDebug() << "Lives : " << lives;
        in >> points;
        qDebug() << "Points : " << points;
        in >> sec;
        qDebug() << "Seconds : " << sec;
        in >> x;
        qDebug() << "X : " << x;
        in >> temp;
        int i = 0;
        while(in.status() == QTextStream::Ok){
            in >> temp >> temp1;
            if(temp != 0 && temp1 != 0){
            qDebug() << "X : " << temp << " ; Y : " << temp1;
            if(i< GameObjects.count()){
                GameObjects[i].setX(temp);
                GameObjects[i].setY(temp1);
                i++;
            }
            else{
                GameObjects.append(GameObject(i,temp, temp1));
                i++;
            }
            in >> temp;
            }
        }
        GameObjects[i-1].~GameObject();
    }
    update();

}
