#ifndef ZEICHENFELD_H
#define ZEICHENFELD_H

#include <QWidget>
#include <QList>
#include "gameobject.h"
#include <QTimer>
#include <QFile>
#include <QBrush>
#include <QTextItem>
#include <QKeyEvent>

class zeichenfeld : public QWidget
{
    Q_OBJECT
public:
    explicit zeichenfeld(QWidget *parent = nullptr);
    void start(void){Updatetimer->start(10);}
    void stop(void){Updatetimer->stop();}
    void changeAnimation(){animated = !animated;if(animated)this->start(); else this->stop();}
    void save(QFile* saveFile);
    void load(QFile* loadFile);
    void pause(){animated = false;stop();}
protected:
    void paintEvent(QPaintEvent* event);
private:
    QList<GameObject> GameObjects;
    //GameObject player;
    QBrush brush0, brush1, brush2, brush3;
    QTimer* Updatetimer;
    int x,y,speed;
    int points;
    bool animated;
    QString SPoints;
    float sec;
    void drawPlayer(QPainter* painter);
    void drawObjects(QPainter* painter, bool move);
    void drawLives(QPainter* painter);
    QImage heartfull;
    QImage heartempty;
    bool freeze;
    int lives;
signals:

public slots:
    void UpdatePoints();
    void UpdateSpeed(QKeyEvent* event);
    void SpawnObject();
};

#endif // ZEICHENFELD_H
